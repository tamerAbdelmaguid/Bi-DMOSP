This folder contains the solved small-sized instances,
along with the results of the tuning experiments of 
the three metaheuristics (MOGWO, NSGA-II and MOSS).

Open *.dmosp files using the DMOSP.exe program to see
the instance structure. You can then run all algorithms
and watch their progress and obtain performance metrics.

The file named DMOSP-5-10-1-0.7-1-2-1-2-1-1.dmosp
corresponds to the sample instance DMOSP-S-1 as provided
in the papers.

You can also, open the "Vectors of permutations solution editor.."
in the "Solve" menu inside the program and load the instance's
Pareto front solutions stored in this folder.

You can also load the *.dat file for the instance data to be
solved using CPLEX OPL Studio. Change the data file referenced
in the "DMOSP.mod" file which contains the OPL CPLEX model.

